---
name: Neon Protocol White
colors:
  surface: '#ffffff'
  surface-dim: '#d4d9f2'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e3e7ff'
  surface-container-highest: '#dce1fb'
  on-surface: '#151b2d'
  on-surface-variant: '#464555'
  inverse-surface: '#2a3043'
  inverse-on-surface: '#eef0ff'
  outline: '#777587'
  outline-variant: '#c7c4d8'
  surface-tint: '#4d44e3'
  primary: '#3525cd'
  on-primary: '#ffffff'
  primary-container: '#4f46e5'
  on-primary-container: '#dad7ff'
  inverse-primary: '#c3c0ff'
  secondary: '#5a5f62'
  on-secondary: '#ffffff'
  secondary-container: '#dce0e4'
  on-secondary-container: '#5e6367'
  tertiary: '#3a495f'
  on-tertiary: '#ffffff'
  tertiary-container: '#516177'
  on-tertiary-container: '#ccdcf7'
  error: '#e11d48'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2dfff'
  primary-fixed-dim: '#c3c0ff'
  on-primary-fixed: '#0f0069'
  on-primary-fixed-variant: '#3323cc'
  secondary-fixed: '#dfe3e7'
  secondary-fixed-dim: '#c3c7cb'
  on-secondary-fixed: '#171c1f'
  on-secondary-fixed-variant: '#43474b'
  tertiary-fixed: '#d3e4fe'
  tertiary-fixed-dim: '#b7c8e1'
  on-tertiary-fixed: '#0b1c30'
  on-tertiary-fixed-variant: '#38485d'
  background: '#f8fafc'
  on-background: '#151b2d'
  surface-variant: '#dce1fb'
  border-subtle: '#e2e8f0'
  success: '#059669'
  warning: '#f59e0b'
  info: '#0284c7'
typography:
  headline-xl:
    fontFamily: JetBrains Mono
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: JetBrains Mono
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-md:
    fontFamily: JetBrains Mono
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 28px
  body-base:
    fontFamily: JetBrains Mono
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
  headline-xl-mobile:
    fontFamily: JetBrains Mono
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  sidebar-width: 260px
  header-height: 64px
  container-max: 1440px
  gutter: 1.5rem
  margin-mobile: 1rem
  margin-desktop: 2rem
---

## Brand & Style

This design system transitions the "Neon Protocol" identity from a dark, high-energy environment to a high-utility, technical "White Theme." The brand personality is rooted in **Minimalism** and **Modern Corporate** aesthetics, prioritizing operational clarity for tool and inventory management.

The UI evokes a sense of "Laboratory Precision"—clean, professional, and lightweight. By removing CRT effects and scanlines, the focus shifts entirely to data integrity and rapid action. The aesthetic relies on heavy whitespace, rigorous grid alignment, and the stark contrast between functional monochrome surfaces and the single "Indigo" action color.

**Key Stylistic Directions:**
- **Minimalism:** Remove all decorative elements that do not aid in decision-making.
- **Technical Refinement:** Use monospaced typography to emphasize data accuracy and a developer-centric feel.
- **Baja Friccion:** Every visual cue must lead the user to the next logical step in the inventory workflow.

## Colors

The palette is strictly controlled to ensure 85% of the interface remains neutral, allowing operational states to command immediate attention. 

- **Action Primary:** Indigo 600 is the exclusive color for "active" intents and primary CTAs.
- **The Slate Scale:** Uses Slate 50 for page backgrounds and pure White for elevation containers to create a subtle hierarchy of depth.
- **Semantic Accents:** Use Emerald (Success), Amber (Warning/Low Stock), and Rose (Error/Destruction) sparingly. These must be the only highly saturated chromatic elements in the interface besides the Primary Action color.

## Typography

This design system adopts **JetBrains Mono** across all roles to maintain its technical heritage. The monospaced nature of the font ensures that numerical data in inventory tables and price lists aligns perfectly, aiding in scanning and comparison.

- **Scale:** Larger sizes (Headline XL/LG) are reserved for page titles and high-level KPIs.
- **Weight:** Use 700 for critical metrics and 500 for navigation and form labels to provide structural contrast without increasing font size.
- **Letter Spacing:** Apply slight tracking reduction on larger headlines to maintain a compact, "engineered" look.

## Layout & Spacing

The layout follows a **Fixed-Fluid Hybrid** model. Navigation and headers are fixed to the viewport, while the content area is fluid up to a maximum width of 1440px to prevent excessive line lengths on ultra-wide monitors.

**Grid Architecture:**
- **Desktop:** A standard 12-column system. The sidebar is a constant 260px anchor.
- **Tablet:** The sidebar collapses to an icon-only rail or a hidden drawer. Content reflows to a 2-column grid for cards.
- **Mobile:** Single column layout. Tables are discarded in favor of vertical "Data Cards."

Spacing follows an 8px (0.5rem) baseline rhythm. Component internal padding should be consistent (e.g., 12px for inputs, 16px for cards) to maintain the "Modern/Sober" feel.

## Elevation & Depth

This design system uses **Tonal Layers** and **Low-contrast Outlines** rather than heavy shadows. In a light theme focused on technical precision, shadows can create unnecessary visual noise.

- **Tier 0 (Base):** Slate 50 (`#f8fafc`) for the application background.
- **Tier 1 (Surface):** White (`#ffffff`) for cards, tables, and sidebar. These surfaces are defined by a 1px Slate 200 (`#e2e8f0`) border.
- **Tier 2 (Interactive):** Elements that require elevation (like Modals or Toasts) use a very soft, diffused shadow (`rgba(15, 23, 42, 0.08)`) and a slightly thicker border to separate them from Tier 1.

## Shapes

The shape language is "Rounded" but controlled. A border radius of **0.5rem (8px) to 0.75rem (12px)** is used to soften the technical monospaced typography, preventing the UI from feeling overly "brutal" or dated.

- **Primary Radius (8px):** Standard for buttons, inputs, and badges.
- **Large Radius (12px):** Reserved for container cards and modals.
- **Interactive States:** On focus, inputs use a 3px ring of `#c7d2fe` (Indigo 200) to provide a clear "soft-glow" hit area without obscuring content.

## Components

### Buttons
- **Primary:** Indigo 600 background, White text. No gradient. 40px height.
- **Secondary:** Slate 100 background, Slate 950 text.
- **Ghost:** Transparent background, Indigo 600 text. Hover state adds Slate 50 background.

### Input Fields
- **Default:** White background, 1px Slate 200 border. Labels are always visible above the input in `label-md`.
- **Focus:** Border changes to Indigo 600 with a 3px Indigo 200 outer ring.

### Data Tables
- **Header:** Slate 50 background, `label-sm` uppercase text.
- **Rows:** White background, 1px bottom border in Slate 200. Hovering a row applies a Slate 50 tint.

### Status Badges
- Small, rounded pills (Radius: 9999px).
- **Available:** Emerald 100 background, Emerald 700 text.
- **Low Stock:** Amber 100 background, Amber 700 text.
- **Out of Stock:** Rose 100 background, Rose 700 text.

### Cards
- White background, 1px Slate 200 border. No shadow unless the card is "Hoverable" or "Draggable," in which case a soft 0 10px 30px shadow is applied.